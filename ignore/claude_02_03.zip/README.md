"""
README: 13-Dimensional Tumor-Immune Dynamics ODE Simulator

This project provides a Python implementation for simulating a deterministic ODE system
that models interactions between tumor cells, immune effector cells, and regulatory
molecules in the tumor microenvironment.

Reference Paper:
"Exploring immunoregulatory mechanisms in the tumor microenvironment: Model and 
design of protocols for cancer remission"

================================================================================
PROJECT STRUCTURE
================================================================================

1. ode_simulator.py (MAIN MODULE)
   - Core ODE system implementation
   - ModelParameters dataclass: Contains all 76 model parameters
   - TumorImmuneModel class: Implements the 13-D ODE system
   - SimulationRunner class: Handles simulation execution and file I/O
   - Variables: S, S_R, C, C_R, M_1, M_2, T_H1, T_H2, T_C, T_reg, IL10, IFN_gamma, IL2

2. simulation_utils.py (UTILITY FUNCTIONS)
   - Helper functions for batch simulations
   - Parameter modification utilities
   - Result loading and analysis functions
   - Predefined initial condition scenarios

3. run_examples.py (DEMONSTRATION SCRIPT)
   - 5 complete examples showing different use cases
   - Baseline simulation
   - Different initial condition scenarios
   - Parameter modification studies
   - Long-term dynamics analysis
   - Result loading and analysis

================================================================================
QUICK START
================================================================================

1. Run a simple simulation:
   python ode_simulator.py

2. Run all examples:
   python run_examples.py

3. In Python code:
   from ode_simulator import TumorImmuneModel, ModelParameters, SimulationRunner
   
   # Create model
   model = TumorImmuneModel()
   
   # Create runner
   runner = SimulationRunner(output_dir='./results')
   
   # Define initial conditions
   ic = np.array([1e6, 1e5, 5e5, 1e4, 1e3, 1e2, 1e3, 1e2, 1e4, 5e2, 1, 1, 1])
   
   # Run simulation
   output = runner.run_simulation(
       model=model,
       t_span=(0, 365),
       initial_conditions=ic,
       max_step=0.1,
       num_points=3650,
       simulation_name='my_sim'
   )

================================================================================
STATE VARIABLES (13-D System)
================================================================================

Tumor Cell Populations:
  x[0]  - S:         Sensitive tumor cells
  x[1]  - S_R:       Drug-resistant tumor cells
  x[2]  - C:         Proliferating cancer cells
  x[3]  - C_R:       Resistant cancer cells

Immune Effector Cells:
  x[4]  - M_1:       M1 macrophages (pro-inflammatory)
  x[5]  - M_2:       M2 macrophages (anti-inflammatory)
  x[6]  - T_H1:      Th1 helper T cells
  x[7]  - T_H2:      Th2 helper T cells
  x[8]  - T_C:       Cytotoxic T cells
  x[9]  - T_reg:     Regulatory T cells (immunosuppressive)

Regulatory Cytokines:
  x[10] - IL10:      Interleukin 10 (anti-inflammatory)
  x[11] - IFN_gamma: Interferon-gamma (pro-inflammatory)
  x[12] - IL2:       Interleukin 2 (T cell proliferation)

================================================================================
PARAMETER CATEGORIES
================================================================================

The model includes 76 parameters organized into groups:

1. INTERACTION RATES (beta_*):
   - Rate of cytokine production by different cell types
   - Default range: 1e-15 to 1e-8

2. DECAY/PROLIFERATION RATES (gamma_*):
   - Cell proliferation and decay rates
   - Default range: 0.01 to 2.0

3. DEATH RATES (delta_*):
   - Cell death/degradation rates
   - Default range: 2e-7 to 19.757

4. ACTIVATION/SATURATION CONSTANTS (lambda_*, k*):
   - Half-saturation constants for Michaelis-Menten kinetics
   - Default range: 0.001 to 5e10

5. INTERACTION COEFFICIENTS (mu_*):
   - Strength of inter-cellular interactions
   - Default range: 1e-10 to 1.5

6. CAPACITY CONSTANTS:
   - C_max, CR_max: Tumor carrying capacities (default 1e10)

7. PHENOTYPIC SWITCHING:
   - p_1, p_2, m_C, m_S: Mutation and switching rates

See Model_and_Params.txt for detailed parameter descriptions and values.

================================================================================
MODEL EQUATIONS
================================================================================

The system is defined by 13 coupled ODEs in the form:

  dx/dt = f(x, params, t)

Key features:
- Logistic growth terms for tumor cells
- Michaelis-Menten kinetics for cytokine interactions
- Predator-prey interactions between immune cells and tumors
- Immunosuppressive feedback from regulatory cells

See ode_simulator.py TumorImmuneModel.ode_system() for the full system.

================================================================================
NUMERICAL INTEGRATION
================================================================================

The simulator uses scipy.integrate.solve_ivp with multiple method options:

Method options:
  - RK45 (default): Explicit Runge-Kutta 4-5 order adaptive method
  - RK23: Lower-order RK method for smooth solutions
  - DOP853: Higher-order method for challenging problems
  - Radau: Implicit method for stiff systems
  - BDF: Implicit multi-step method for stiff systems

Solver parameters (controllable):
  - max_step: Maximum step size (default 0.1)
  - rtol: Relative tolerance (default 1e-6)
  - atol: Absolute tolerance (default 1e-9)
  - dense_output: Enable interpolation (default True)

Example with tight tolerance:
  results = model.simulate(
      t_span=(0, 100),
      initial_conditions=ic,
      max_step=0.05,
      rtol=1e-8,
      atol=1e-11
  )

================================================================================
OUTPUT FILES
================================================================================

For each simulation, the following files are saved:

1. trajectory.npy
   - Binary NumPy file with solution array
   - Shape: (13, n_time_points)
   - Contains states at each time point

2. time.npy
   - Binary NumPy file with time points
   - Shape: (n_time_points,)

3. trajectory.csv
   - Human-readable CSV format
   - Columns: time, S, S_R, C, C_R, M_1, M_2, T_H1, T_H2, T_C, T_reg, IL10, IFN_gamma, IL2
   - Can be opened in Excel or analyzed with standard tools

4. metadata.json
   - JSON file with simulation metadata
   - Includes: time span, initial conditions, solver info, success status
   - Stores number of function evaluations

5. parameters.json
   - JSON file with all model parameters used in the simulation
   - Can be reloaded to recreate exact same simulation

================================================================================
USAGE EXAMPLES
================================================================================

Example 1: Baseline Simulation
-------------------------------
from ode_simulator import TumorImmuneModel, SimulationRunner
import numpy as np

model = TumorImmuneModel()
runner = SimulationRunner()

ic = np.array([1e6, 1e5, 5e5, 1e4, 1e3, 1e2, 1e3, 1e2, 1e4, 5e2, 1, 1, 1])

output = runner.run_simulation(
    model=model,
    t_span=(0, 365),
    initial_conditions=ic,
    simulation_name='baseline'
)


Example 2: Modified Parameters
-------------------------------
from ode_simulator import ModelParameters, TumorImmuneModel, SimulationRunner

# Create parameters with custom values
params = ModelParameters(
    gamma_S=0.2,        # Higher tumor growth
    delta_Tc=3.0,       # Higher T cell death
    lambda_Tc1=2e5      # Different T cell activation
)

model = TumorImmuneModel(params=params)
runner = SimulationRunner()

output = runner.run_simulation(
    model=model,
    t_span=(0, 730),
    initial_conditions=ic,
    simulation_name='modified_params'
)


Example 3: Parameter Sweep
---------------------------
from simulation_utils import modify_parameter

base_params = ModelParameters()
sweep_values = [0.05, 0.1, 0.15, 0.2, 0.25]

for i, gamma_S_val in enumerate(sweep_values):
    params = modify_parameter(base_params.to_dict(), 'gamma_S', gamma_S_val)
    model = TumorImmuneModel(params=params)
    
    output = runner.run_simulation(
        model=model,
        t_span=(0, 365),
        initial_conditions=ic,
        simulation_name=f'gamma_S_sweep_{i}'
    )


Example 4: Loading and Analyzing Results
-----------------------------------------
from simulation_utils import load_trajectory, get_final_state

# Load previous results
traj = load_trajectory('./simulation_results/baseline')

t = traj['t']
x = traj['x']
metadata = traj['metadata']

# Get final state
final = get_final_state('./simulation_results/baseline')

# Analyze
print(f"Tumor burden at end: {final['C'] + final['C_R']}")
print(f"Immune cells at end: {final['T_C'] + final['T_reg']}")

================================================================================
ADVANCED USAGE
================================================================================

Custom ODE Solver Parameters:
----------------------------
output = model.simulate(
    t_span=(0, 365),
    initial_conditions=ic,
    method='DOP853',        # Use 8th order method
    max_step=0.05,          # Smaller steps
    rtol=1e-8,              # Tighter tolerance
    atol=1e-11,
    dense_output=True       # For smooth interpolation
)

# Access dense solution
sol = output['sol']
t_interp = np.linspace(0, 365, 10000)
x_interp = sol(t_interp)  # Get smooth solution at any time


Using Initial Condition Presets:
-------------------------------
from simulation_utils import (
    create_immune_boosted_initial_conditions,
    create_immune_suppressed_initial_conditions,
    create_high_tumor_burden_initial_conditions
)

# Run with different immune scenarios
scenarios = {
    'boosted': create_immune_boosted_initial_conditions(),
    'suppressed': create_immune_suppressed_initial_conditions(),
    'high_burden': create_high_tumor_burden_initial_conditions()
}

for name, ic in scenarios.items():
    output = runner.run_simulation(
        model=model,
        t_span=(0, 365),
        initial_conditions=ic,
        simulation_name=f'scenario_{name}'
    )

================================================================================
TROUBLESHOOTING
================================================================================

Problem: Simulation runs very slowly
Solution: Reduce num_points, increase max_step, use RK45 method

Problem: Solution diverges or has numerical issues
Solution: 
  - Tighten rtol/atol
  - Reduce max_step
  - Switch to BDF or Radau method
  - Check initial conditions for unrealistic values

Problem: Memory errors with long simulations
Solution:
  - Don't store dense_output if not needed
  - Reduce num_points
  - Implement trajectory binning/downsampling

Problem: Results look unrealistic
Solution:
  - Verify parameter values are correct
  - Check that initial conditions are in reasonable ranges
  - Verify ODE system is correctly specified

================================================================================
NEXT STEPS IN PROJECT
================================================================================

This is the first component. Planned extensions:

1. BIFURCATION ANALYSIS
   - Find parameter regions with qualitative behavior changes
   - Identify tipping points and bistable regimes
   - Plot bifurcation diagrams

2. SENSITIVITY ANALYSIS
   - Local sensitivity: Jacobian-based analysis
   - Global sensitivity: SOBOL/Morris sampling
   - Parameter importance ranking

3. VISUALIZATION
   - Time series plots for all variables
   - Phase portraits and 3D trajectories
   - Heatmaps for parameter sweeps
   - Phase plane analysis

4. PARAMETER ESTIMATION
   - Fit to synthetic data
   - Uncertainty quantification
   - MCMC for Bayesian inference

5. CONTROL STRATEGIES
   - Optimal treatment protocols
   - Immunotherapy dosing schedules
   - Multi-objective optimization

================================================================================
CITATIONS AND REFERENCES
================================================================================

Base model paper:
"Exploring immunoregulatory mechanisms in the tumor microenvironment: Model and 
design of protocols for cancer remission"

Data files provided:
- Model_and_Params.txt: Parameter definitions and equations
- Supplementary_Text_S1.pdf: Supplementary information
- Main paper PDF: Full research paper

================================================================================
LICENSE AND USAGE
================================================================================

This code is provided for research and educational purposes.
Please cite the original research paper when using this model.

Dependencies:
- numpy
- scipy (specifically scipy.integrate.solve_ivp)
- Python 3.7+

================================================================================
CONTACT AND SUPPORT
================================================================================

For questions about the model:
- Refer to the original research paper
- Check Model_and_Params.txt for parameter definitions
- Review the governing equations in ode_simulator.py

For implementation questions:
- See docstrings in ode_simulator.py
- Review examples in run_examples.py
- Check utility functions in simulation_utils.py

================================================================================
"""

# If run as script, print this documentation
if __name__ == '__main__':
    import inspect
    doc = inspect.getdoc(__import__(__name__))
    print(doc)
