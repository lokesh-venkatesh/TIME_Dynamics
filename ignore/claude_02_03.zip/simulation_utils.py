"""
Utility functions for running batch simulations and parameter variations.

This module provides convenient functions for:
- Running multiple simulations with different parameters
- Varying individual parameters
- Loading and analyzing saved results
"""

import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json
from ode_simulator import TumorImmuneModel, ModelParameters, SimulationRunner


def create_custom_initial_conditions(
    S: float = 1e6,
    S_R: float = 1e5,
    C: float = 5e5,
    C_R: float = 1e4,
    M_1: float = 1e3,
    M_2: float = 1e2,
    T_H1: float = 1e3,
    T_H2: float = 1e2,
    T_C: float = 1e4,
    T_reg: float = 5e2,
    IL10: float = 1.0,
    IFN_gamma: float = 1.0,
    IL2: float = 1.0
) -> np.ndarray:
    """
    Create custom initial conditions array.
    
    Args:
        Individual values for each of the 13 state variables
        
    Returns:
        Initial conditions array
    """
    return np.array([S, S_R, C, C_R, M_1, M_2, T_H1, T_H2, T_C, T_reg, IL10, IFN_gamma, IL2])


def create_immune_boosted_initial_conditions() -> np.ndarray:
    """Create initial conditions with stronger immune response."""
    return create_custom_initial_conditions(
        S=1e6, S_R=1e5, C=5e5, C_R=1e4,
        M_1=5e3,      # 5x higher M1 macrophages
        M_2=5e2,      # 5x higher M2 macrophages
        T_H1=5e3,     # 5x higher Th1
        T_H2=5e2,     # 5x higher Th2
        T_C=5e4,      # 5x higher Tc
        T_reg=1e3,    # 2x higher Treg
        IL10=2.0,
        IFN_gamma=2.0,
        IL2=2.0
    )


def create_immune_suppressed_initial_conditions() -> np.ndarray:
    """Create initial conditions with suppressed immune response."""
    return create_custom_initial_conditions(
        S=1e6, S_R=1e5, C=5e5, C_R=1e4,
        M_1=1e2,      # 10x lower M1 macrophages
        M_2=1e1,      # 10x lower M2 macrophages
        T_H1=1e2,     # 10x lower Th1
        T_H2=1e1,     # 10x lower Th2
        T_C=1e3,      # 10x lower Tc
        T_reg=5e2,    # Same Treg
        IL10=0.1,
        IFN_gamma=0.1,
        IL2=0.1
    )


def create_high_tumor_burden_initial_conditions() -> np.ndarray:
    """Create initial conditions with high tumor burden."""
    return create_custom_initial_conditions(
        S=1e7,        # 10x higher sensitive tumor
        S_R=1e6,      # 10x higher resistant tumor
        C=5e6,        # 10x higher proliferating cancer
        C_R=1e5,      # 10x higher resistant cancer
        M_1=1e3,
        M_2=1e2,
        T_H1=1e3,
        T_H2=1e2,
        T_C=1e4,
        T_reg=5e2,
        IL10=1.0,
        IFN_gamma=1.0,
        IL2=1.0
    )


def modify_parameter(param_dict: Dict, param_name: str, value: float) -> ModelParameters:
    """
    Create new ModelParameters with a single parameter modified.
    
    Args:
        param_dict: Dictionary of parameters (from default parameters)
        param_name: Name of parameter to modify
        value: New value for the parameter
        
    Returns:
        New ModelParameters instance
    """
    modified_dict = param_dict.copy()
    modified_dict[param_name] = value
    return ModelParameters.from_dict(modified_dict)


def run_parameter_sweep(
    base_model: TumorImmuneModel,
    t_span: Tuple[float, float],
    initial_conditions: np.ndarray,
    param_name: str,
    param_values: List[float],
    runner: SimulationRunner,
    max_step: float = 0.1,
    num_points: int = 1000,
    base_name: str = "sweep"
) -> Dict:
    """
    Run multiple simulations varying a single parameter.
    
    Args:
        base_model: Base TumorImmuneModel instance
        t_span: Time span for simulations
        initial_conditions: Initial conditions for all runs
        param_name: Name of parameter to sweep
        param_values: List of parameter values to test
        runner: SimulationRunner instance
        max_step: Max step size for ODE solver
        num_points: Number of output points
        base_name: Base name for simulation results
        
    Returns:
        Dictionary with results for all parameter values
    """
    
    sweep_results = {
        'param_name': param_name,
        'param_values': param_values,
        'simulations': []
    }
    
    for i, param_value in enumerate(param_values):
        print(f"\n[{i+1}/{len(param_values)}] Running sweep with {param_name}={param_value}")
        
        # Create modified model
        modified_params = modify_parameter(base_model.params.to_dict(), param_name, param_value)
        modified_model = TumorImmuneModel(params=modified_params)
        
        # Run simulation
        sim_name = f"{base_name}_{param_name}_{i:03d}"
        sim_output = runner.run_simulation(
            model=modified_model,
            t_span=t_span,
            initial_conditions=initial_conditions,
            max_step=max_step,
            num_points=num_points,
            simulation_name=sim_name,
            save_results=True
        )
        
        sweep_results['simulations'].append({
            'param_value': param_value,
            'simulation_name': sim_name,
            'final_state': sim_output['results']['x'][-1].tolist(),
            'metadata': sim_output['metadata']
        })
    
    return sweep_results


def load_trajectory(sim_dir: str) -> Dict:
    """
    Load a saved trajectory and its metadata.
    
    Args:
        sim_dir: Path to simulation results directory
        
    Returns:
        Dictionary with 't', 'x', and 'metadata'
    """
    sim_path = Path(sim_dir)
    
    # Load arrays
    t = np.load(sim_path / 'time.npy')
    x = np.load(sim_path / 'trajectory.npy')
    
    # Load metadata
    with open(sim_path / 'metadata.json', 'r') as f:
        metadata = json.load(f)
    
    return {
        't': t,
        'x': x.T,  # Transpose to match simulation output format
        'metadata': metadata
    }


def get_final_state(sim_dir: str) -> Dict:
    """
    Get the final state values for a simulation.
    
    Args:
        sim_dir: Path to simulation results directory
        
    Returns:
        Dictionary mapping variable names to final values
    """
    data = load_trajectory(sim_dir)
    from ode_simulator import TumorImmuneModel
    
    final_state = data['x'][-1]
    return dict(zip(TumorImmuneModel.variable_names, final_state))


def compare_simulations(sim_dirs: List[str], 
                       variable_name: str = None) -> Dict:
    """
    Compare final states across multiple simulations.
    
    Args:
        sim_dirs: List of paths to simulation directories
        variable_name: If specified, only compare this variable
        
    Returns:
        Dictionary with comparison results
    """
    from ode_simulator import TumorImmuneModel
    
    results = {}
    
    for sim_dir in sim_dirs:
        sim_name = Path(sim_dir).name
        final_states = get_final_state(sim_dir)
        
        if variable_name:
            results[sim_name] = final_states.get(variable_name)
        else:
            results[sim_name] = final_states
    
    return results


if __name__ == '__main__':
    print("Utility module for batch simulations loaded.")
    print("\nAvailable functions:")
    print("  - create_custom_initial_conditions(...)")
    print("  - create_immune_boosted_initial_conditions()")
    print("  - create_immune_suppressed_initial_conditions()")
    print("  - create_high_tumor_burden_initial_conditions()")
    print("  - modify_parameter(param_dict, param_name, value)")
    print("  - run_parameter_sweep(...)")
    print("  - load_trajectory(sim_dir)")
    print("  - get_final_state(sim_dir)")
    print("  - compare_simulations(sim_dirs, variable_name)")
