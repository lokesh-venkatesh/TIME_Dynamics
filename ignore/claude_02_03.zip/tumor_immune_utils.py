"""
Utilities and examples for using the tumor-immune ODE simulator.

This module provides:
1. Helper functions to load and visualize results
2. Example simulations with different initial conditions and parameters
3. Functions to compare trajectories
"""

import numpy as np
from pathlib import Path
import json
from simulate_tumor_immune_model import (
    TumorImmuneModel, 
    ModelParameters, 
    load_simulation_results
)


def print_simulation_summary(npz_path: Path) -> None:
    """
    Load and print a summary of a saved simulation.
    
    Args:
        npz_path: Path to the .npz file
    """
    # Load data
    result = load_simulation_results(npz_path)
    
    # Load summary JSON
    json_path = npz_path.with_suffix('.json')
    if json_path.exists():
        with open(json_path, 'r') as f:
            summary = json.load(f)
        
        print("\n" + "=" * 70)
        print(f"SIMULATION SUMMARY: {npz_path.name}")
        print("=" * 70)
        print(f"Status: {summary['integration_status']}")
        print(f"Message: {summary['message']}")
        print(f"Time span: {summary['time_span'][0]} to {summary['time_span'][1]} days")
        print(f"Number of time steps: {summary['num_time_steps']}")
        print()
    
    # Print final state
    t = result['t']
    y = result['y']
    state_names = result['state_names']
    
    print("Initial State:")
    print("-" * 70)
    for name, val in zip(state_names, y[:, 0]):
        print(f"  {name:12s}: {val:.6e}")
    
    print("\nFinal State:")
    print("-" * 70)
    for name, val in zip(state_names, y[:, -1]):
        print(f"  {name:12s}: {val:.6e}")
    
    print("\nState Statistics (over entire time course):")
    print("-" * 70)
    for i, name in enumerate(state_names):
        print(f"  {name:12s}: min={np.min(y[i, :]):.6e}, "
              f"max={np.max(y[i, :]):.6e}, "
              f"mean={np.mean(y[i, :]):.6e}")
    print("=" * 70 + "\n")


def get_state_by_name(result, state_name: str) -> tuple:
    """
    Extract time and values for a specific state variable.
    
    Args:
        result: Dictionary from load_simulation_results or simulate()
        state_name: Name of the state variable (e.g., 'T_C', 'IL10')
    
    Returns:
        Tuple of (time_array, values_array)
    """
    state_names = result['state_names']
    if state_name not in state_names:
        raise ValueError(f"State '{state_name}' not found. Available: {state_names}")
    
    idx = state_names.index(state_name)
    return result['t'], result['y'][idx, :]


def compute_phase_portrait(result, 
                           state1: str, 
                           state2: str) -> tuple:
    """
    Extract two state variables for phase portrait plotting.
    
    Args:
        result: Dictionary from load_simulation_results or simulate()
        state1: Name of first state variable
        state2: Name of second state variable
    
    Returns:
        Tuple of (values1, values2) for plotting
    """
    t1, y1 = get_state_by_name(result, state1)
    t2, y2 = get_state_by_name(result, state2)
    
    return y1, y2


def example_default_simulation():
    """
    Example 1: Run the default simulation.
    """
    from simulate_tumor_immune_model import run_simulation
    
    print("\n" + "=" * 70)
    print("EXAMPLE 1: Default Simulation")
    print("=" * 70)
    
    result = run_simulation(
        duration=100.0,
        dt=0.01,
        output_file='example_default.npz'
    )
    
    print_simulation_summary(Path('example_default.npz'))


def example_custom_initial_conditions():
    """
    Example 2: Simulation with custom initial conditions (high tumor burden).
    """
    from simulate_tumor_immune_model import run_simulation
    
    print("\n" + "=" * 70)
    print("EXAMPLE 2: High Tumor Burden")
    print("=" * 70)
    
    # Higher initial tumor populations
    x0_high_burden = np.array([
        1e9,    # S: Sensitive tumor cells (increased)
        1e8,    # S_R: Resistant tumor cells (increased)
        1e7,    # C: Cancer stem cells (cycling) (increased)
        1e6,    # C_R: Cancer stem cells (resistant) (increased)
        1e3,    # M_1: M1 macrophages
        1e3,    # M_2: M2 macrophages
        1e3,    # T_H1: T helper 1 cells
        1e2,    # T_H2: T helper 2 cells
        1e3,    # T_C: Cytotoxic T lymphocytes
        1e3,    # T_reg: Regulatory T cells
        1e-3,   # IL10: Interleukin-10
        1e-3,   # IFN_gamma: Interferon-gamma
        1e-3    # IL2: Interleukin-2
    ])
    
    result = run_simulation(
        duration=100.0,
        dt=0.01,
        x0=x0_high_burden,
        output_file='example_high_burden.npz'
    )
    
    print_simulation_summary(Path('example_high_burden.npz'))


def example_immunotherapy_boost():
    """
    Example 3: Simulation with enhanced immune response 
    (modified parameters to boost T cell activation).
    """
    from simulate_tumor_immune_model import run_simulation
    
    print("\n" + "=" * 70)
    print("EXAMPLE 3: Enhanced Immune Response (Immunotherapy)")
    print("=" * 70)
    
    # Create custom parameters with boosted immune parameters
    params = ModelParameters()
    
    # Increase T cell proliferation rates
    params.gamma_Th1 *= 1.5
    params.gamma_Tc *= 1.5
    params.lambda_Th1 *= 0.8  # Lower threshold for activation
    params.lambda_Tc1 *= 0.8
    
    # Increase cytokine production
    params.beta_Th1CK2 *= 2.0
    params.beta_Tc *= 2.0
    
    result = run_simulation(
        duration=100.0,
        dt=0.01,
        params=params,
        output_file='example_immunotherapy.npz'
    )
    
    print_simulation_summary(Path('example_immunotherapy.npz'))


def example_detailed_output():
    """
    Example 4: Finer time resolution for detailed analysis.
    """
    from simulate_tumor_immune_model import run_simulation
    
    print("\n" + "=" * 70)
    print("EXAMPLE 4: High-Resolution Simulation (fine time step)")
    print("=" * 70)
    
    result = run_simulation(
        duration=50.0,  # Shorter duration
        dt=0.001,       # Finer time step
        output_file='example_high_resolution.npz'
    )
    
    print_simulation_summary(Path('example_high_resolution.npz'))


def example_ensemble_comparison():
    """
    Example 5: Run multiple simulations with slightly perturbed initial conditions
    and compare trajectories.
    """
    from simulate_tumor_immune_model import run_simulation
    
    print("\n" + "=" * 70)
    print("EXAMPLE 5: Ensemble of Simulations")
    print("=" * 70)
    print("Running 3 simulations with ±10% perturbation in initial conditions...\n")
    
    # Base initial conditions
    x0_base = np.array([
        1e7, 1e6, 1e5, 1e4, 1e3, 1e3, 1e3, 1e2, 1e3, 1e3, 1e-3, 1e-3, 1e-3
    ])
    
    results = []
    perturbations = [1.0, 0.9, 1.1]
    
    for i, perturb in enumerate(perturbations):
        x0 = x0_base * perturb
        print(f"Running simulation {i+1}/3 (perturbation: {perturb}x)...")
        
        result = run_simulation(
            duration=100.0,
            dt=0.01,
            x0=x0,
            output_file=f'example_ensemble_{i+1}.npz'
        )
        results.append(result)
    
    # Compare final states
    print("\n" + "-" * 70)
    print("Comparison of final states:")
    print("-" * 70)
    state_names = results[0]['state_names']
    
    for state_name in state_names:
        print(f"\n{state_name}:")
        for i, result in enumerate(results):
            _, y = get_state_by_name(result, state_name)
            print(f"  Run {i+1}: {y[-1]:.6e}")


def example_custom_parameters():
    """
    Example 6: Detailed example showing how to modify parameters.
    """
    from simulate_tumor_immune_model import run_simulation
    
    print("\n" + "=" * 70)
    print("EXAMPLE 6: Custom Parameter Modification")
    print("=" * 70)
    print("Testing increased tumor killing rate by T cells...\n")
    
    # Create two parameter sets: baseline and increased T cell killing
    params_baseline = ModelParameters()
    
    params_killing = ModelParameters()
    params_killing.tck *= 2.0  # Double T cell killing rate
    params_killing.delta_C *= 0.8  # Slightly reduce tumor cell growth
    
    # Run both simulations
    result_baseline = run_simulation(
        duration=100.0,
        dt=0.01,
        params=params_baseline,
        output_file='example_baseline.npz'
    )
    
    print("\nRunning simulation with increased T cell killing...\n")
    
    result_killing = run_simulation(
        duration=100.0,
        dt=0.01,
        params=params_killing,
        output_file='example_killing.npz'
    )
    
    # Compare tumor populations
    print("\n" + "-" * 70)
    print("COMPARISON: Tumor Cell Populations")
    print("-" * 70)
    
    for tumor_state in ['S', 'S_R', 'C', 'C_R']:
        _, y_base = get_state_by_name(result_baseline, tumor_state)
        _, y_kill = get_state_by_name(result_killing, tumor_state)
        
        print(f"\n{tumor_state}:")
        print(f"  Baseline - Final: {y_base[-1]:.6e}")
        print(f"  Killing  - Final: {y_kill[-1]:.6e}")
        print(f"  Reduction: {(1 - y_kill[-1]/y_base[-1])*100:.2f}%")


if __name__ == "__main__":
    """
    Run various examples demonstrating different usage patterns.
    Uncomment the examples you want to run.
    """
    
    # Run all examples
    example_default_simulation()
    example_custom_initial_conditions()
    example_immunotherapy_boost()
    example_detailed_output()
    example_ensemble_comparison()
    example_custom_parameters()
    
    print("\n" + "=" * 70)
    print("All examples completed!")
    print("=" * 70)
    print("\nOutput files generated:")
    print("  - example_default.npz")
    print("  - example_high_burden.npz")
    print("  - example_immunotherapy.npz")
    print("  - example_high_resolution.npz")
    print("  - example_ensemble_*.npz (3 files)")
    print("  - example_baseline.npz")
    print("  - example_killing.npz")
    print("\nEach .npz file has a corresponding .json file with metadata.")
    print("=" * 70 + "\n")
