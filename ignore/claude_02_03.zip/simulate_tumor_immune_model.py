"""
Simulation script for the 13-dimensional deterministic ODE system modeling
immunoregulatory mechanisms in the tumor microenvironment.

This script simulates the dynamics of tumor cell populations, immune effector cells,
inhibitory cells, and cytokines in a tumor microenvironment.

State variables (13-D):
    x[0]:  S       - Sensitive tumor cells
    x[1]:  S_R     - Resistant tumor cells
    x[2]:  C       - Cancer stem cells (cycling)
    x[3]:  C_R     - Cancer stem cells (resistant)
    x[4]:  M_1     - M1 macrophages (pro-inflammatory)
    x[5]:  M_2     - M2 macrophages (anti-inflammatory)
    x[6]:  T_H1    - T helper 1 cells
    x[7]:  T_H2    - T helper 2 cells
    x[8]:  T_C     - Cytotoxic T lymphocytes
    x[9]:  T_reg   - Regulatory T cells
    x[10]: IL10    - Interleukin-10 cytokine
    x[11]: IFN_g   - Interferon-gamma cytokine
    x[12]: IL2     - Interleukin-2 cytokine

References:
    Model from: "Exploring immunoregulatory mechanisms in the tumour microenvironment:
    Model and design of protocols for cancer remission"
"""

import numpy as np
from scipy.integrate import solve_ivp
from dataclasses import dataclass
from typing import Tuple, Dict, Optional
import json
from pathlib import Path


@dataclass
class ModelParameters:
    """Container for all model parameters."""
    
    # Tumor cell interaction parameters
    beta_M2: float = 1e-15
    beta_Tc: float = 1e-8
    beta_Th1CK2: float = 1e-7
    beta_Th1CK3: float = 1e-8
    beta_Th2: float = 1e-9
    beta_Treg: float = 1e-10
    
    # Death/degradation rate parameters
    gamma_C: float = 0.1282
    gamma_CR: float = 0.1282
    gamma_M1: float = 0.7
    gamma_M2: float = 0.01
    gamma_S: float = 0.15
    gamma_Tc: float = 1.0
    gamma_Th1: float = 2.0
    gamma_Th2: float = 2.0
    gamma_Treg: float = 0.3
    
    # Degradation/decay rate parameters
    delta_C: float = 0.8055
    delta_Ck1: float = 19.757
    delta_Ck2: float = 6.1212
    delta_Ck3: float = 8.664339
    delta_CR: float = 5.37e-5
    delta_M1: float = 1.02
    delta_M2: float = 0.05
    delta_S: float = 2e-7
    delta_Tc: float = 5.2939
    delta_Th1: float = 2.0
    delta_Th2: float = 2.0
    delta_Treg: float = 1.0
    
    # Proliferation rate parameters
    lambda_M1: float = 1e8
    lambda_M2: float = 1e6
    lambda_Tc1: float = 1e5
    lambda_Tc2: float = 5e5
    lambda_Tc3: float = 5e10
    lambda_Tc4: float = 1e5
    lambda_Th1: float = 1e5
    lambda_Th2: float = 1e5
    lambda_Treg2: float = 1e7
    
    # Interaction/killing rate parameters
    mu_C1: float = 0.75
    mu_C2: float = 0.9
    mu_S: float = 0.17
    mu_SR: float = 0.18
    mu_TcS: float = 1e-10
    mu_TcTreg: float = 1.5e-5
    mu_Th1Ck1: float = 1e-9
    mu_Th1Ck3: float = 0.1245
    mu_TregCk1: float = 1e-7
    mu_M1Ck2: float = 0.01
    mu_M2Ck1: float = 0.02
    
    # Carrying capacity parameters
    C_max: float = 1e10
    CR_max: float = 1e10
    
    # Michaelis-Menten and Hill coefficients
    k1: float = 10.0
    k2: float = 10.0
    k3: float = 2.0531
    k4: float = 3.02
    k5: float = 6.7979
    k6: float = 6.9937
    k8: float = 0.01
    k9: float = 0.001
    k11: float = 0.001
    k_7: float = 0.2
    k_10: float = 0.0
    
    # Tumor cell elimination/conversion rates
    ktc1: float = 1e9
    ktc2: float = 1e8
    ktc3: float = 1e9
    ktc4: float = 1e9
    
    # Mutation/phenotype switch rates
    m_C: float = 0.01
    m_S: float = 4e-7
    
    # Differentiation/commitment probabilities
    p_1: float = 0.2
    p_2: float = 0.05
    
    # Reversion/reprogramming rates
    r_1: float = 0.0001
    r_2: float = 1e-5
    
    # T cell killing/cytotoxicity rate
    tck: float = 0.1


class TumorImmuneModel:
    """
    ODE system for tumor-immune dynamics in the microenvironment.
    
    Attributes:
        params (ModelParameters): Model parameters
        state_names (list): Names of the 13 state variables
    """
    
    def __init__(self, params: Optional[ModelParameters] = None):
        """
        Initialize the model.
        
        Args:
            params: ModelParameters object. If None, uses default parameters.
        """
        self.params = params if params is not None else ModelParameters()
        self.state_names = [
            'S', 'S_R', 'C', 'C_R', 'M_1', 'M_2', 'T_H1', 'T_H2', 
            'T_C', 'T_reg', 'IL10', 'IFN_gamma', 'IL2'
        ]
    
    def _rhs(self, t: float, x: np.ndarray) -> np.ndarray:
        """
        Compute the right-hand side of the ODE system.
        
        Args:
            t: Current time (not used in autonomous system, kept for compatibility)
            x: State vector [S, S_R, C, C_R, M_1, M_2, T_H1, T_H2, T_C, T_reg, IL10, IFN_gamma, IL2]
        
        Returns:
            dx: Time derivatives of state variables
        """
        # Unpack state variables
        S, S_R, C, C_R, M_1, M_2, T_H1, T_H2, T_C, T_reg, IL10, IFN_gamma, IL2 = x
        
        # Extract parameters for readability
        p = self.params
        
        # Ensure non-negativity (numerical stability)
        x = np.maximum(x, 0.0)
        S, S_R, C, C_R, M_1, M_2, T_H1, T_H2, T_C, T_reg, IL10, IFN_gamma, IL2 = x
        
        # Initialize derivatives
        dx = np.zeros(13)
        
        # ========== TUMOR CELL POPULATIONS ==========
        # Sensitive tumor cells (S)
        dx[0] = (p.gamma_S * (1 - p.m_S) * (1 - p.p_1 - p.p_2) * S 
                 - (p.delta_S + p.p_2 * p.gamma_S + p.gamma_S * p.m_S * p.p_1 / 2) * S
                 - (p.mu_S * S * IFN_gamma) / (p.k1 + IFN_gamma)
                 - (p.tck * S * T_C) / (p.ktc1 + T_C))
        
        # Resistant tumor cells (S_R)
        dx[1] = ((p.gamma_S * (1 - p.p_1 - p.p_2) - (p.delta_S + p.p_2 * p.gamma_S)) * S_R
                 + p.m_S * p.gamma_S * (1 - p.p_1 / 2 - p.p_2) * S
                 - (p.mu_SR * S_R * IFN_gamma) / (p.k2 + IFN_gamma)
                 - (p.tck * S_R * T_C) / (p.ktc2 + T_C))
        
        # Cancer stem cells - cycling (C)
        dx[2] = (p.gamma_C * (1 - p.m_C) * np.log((p.C_max) / (C + p.r_1)) * C 
                 + p.gamma_S * (p.p_1 + p.p_2) * S
                 - p.delta_C * C
                 - p.m_C * p.gamma_C * C
                 + (p.mu_C1 * C * IL10) / (IL10 + p.k3)
                 - (p.mu_C2 * C * IFN_gamma) / (IFN_gamma + p.k4)
                 - (p.tck * C * T_C) / (p.ktc3 + T_C))
        
        # Cancer stem cells - resistant (C_R)
        dx[3] = (p.gamma_C * np.log((p.CR_max) / (C_R + p.r_2)) * C_R
                 + p.gamma_S * S_R * (p.p_1 + p.p_2)
                 + p.m_C * p.gamma_C * C
                 - p.delta_CR * C_R
                 + (p.mu_C1 * C_R * IL10) / (IL10 + p.k5)
                 - (p.mu_C2 * C_R * IFN_gamma) / (IFN_gamma + p.k6)
                 - (p.tck * C_R * T_C) / (p.ktc4 + T_C))
        
        # ========== EFFECTOR POPULATIONS ==========
        # M1 macrophages (pro-inflammatory)
        dx[4] = (p.gamma_M1 * M_1 * ((C + C_R) / (M_1 + p.lambda_M1))
                 - p.delta_M1 * M_1
                 + (p.mu_M1Ck2 * M_1 * IFN_gamma) / (IFN_gamma + p.k_7))
        
        # M2 macrophages (anti-inflammatory)
        dx[5] = (p.gamma_M2 * M_2 * ((C + C_R) / (M_2 + p.lambda_M2))
                 - p.delta_M2 * M_2
                 + (p.mu_M2Ck1 * M_2 * IL10) / (IL10 + p.k_10))
        
        # T helper 1 cells
        dx[6] = (p.gamma_Th1 * ((T_H1 * M_1) / (p.lambda_Th1 + T_H1))
                 - p.delta_Th1 * T_H1
                 - (p.mu_Th1Ck1 * IL10 * T_H1) / (IL10 + p.k8)
                 + (p.mu_Th1Ck3 * IL2 * T_H1) / (IL2 + p.k9))
        
        # T helper 2 cells
        dx[7] = (p.gamma_Th2 * ((T_H2 * M_2) / (p.lambda_Th2 + T_H2))
                 - p.delta_Th2 * T_H2)
        
        # Cytotoxic T lymphocytes
        dx[8] = (p.gamma_Tc * T_C * ((C + C_R) / (T_C + p.lambda_Tc1))
                 + p.gamma_Tc * ((T_C * T_H1) / (T_C + p.lambda_Tc4))
                 - p.mu_TcS * T_C * ((S + S_R) / (T_C + p.lambda_Tc2))
                 - p.delta_Tc * T_C
                 - p.mu_TcTreg * T_C * ((T_reg) / (p.lambda_Tc3 + T_reg)))
        
        # ========== INHIBITOR POPULATIONS ==========
        # Regulatory T cells
        dx[9] = (p.gamma_Treg * ((T_reg * M_2) / (T_reg + p.lambda_Treg2))
                 - p.delta_Treg * T_reg
                 + p.mu_TregCk1 * ((IL10 * T_reg) / (T_reg + p.k11)))
        
        # ========== CYTOKINE POPULATIONS ==========
        # Interleukin-10
        dx[10] = (p.beta_M2 * M_2
                  - p.delta_Ck1 * IL10
                  + p.beta_Treg * T_reg
                  + p.beta_Th2 * T_H2)
        
        # Interferon-gamma
        dx[11] = (p.beta_Th1CK2 * T_H1
                  + p.beta_Tc * T_C
                  - p.delta_Ck2 * IFN_gamma)
        
        # Interleukin-2
        dx[12] = (p.beta_Th1CK3 * T_H1
                  - p.delta_Ck3 * IL2)
        
        return dx
    
    def simulate(self, 
                 x0: np.ndarray,
                 t_span: Tuple[float, float],
                 t_eval: Optional[np.ndarray] = None,
                 max_step: float = 0.01,
                 method: str = 'RK45',
                 rtol: float = 1e-6,
                 atol: float = 1e-9) -> Dict:
        """
        Simulate the ODE system.
        
        Args:
            x0: Initial conditions (13-D array)
            t_span: Tuple (t0, tf) specifying start and end times
            t_eval: Times at which to store solutions. If None, uses dense output with max_step.
            max_step: Maximum time step for integration (only used if t_eval is None)
            method: Integration method ('RK45', 'RK23', 'DOP853', 'Radau', 'BDF')
            rtol: Relative tolerance
            atol: Absolute tolerance
        
        Returns:
            Dictionary containing:
                't': Time array
                'y': Solution array (13 x len(t))
                'message': Integration completion message
                'status': Integration status code (0 for success)
        """
        
        # Generate time evaluation points if not provided
        if t_eval is None:
            num_steps = int((t_span[1] - t_span[0]) / max_step) + 1
            t_eval = np.linspace(t_span[0], t_span[1], num_steps)
        
        # Solve the ODE system
        sol = solve_ivp(
            self._rhs,
            t_span,
            x0,
            t_eval=t_eval,
            method=method,
            dense_output=False,
            events=None,
            max_step=max_step,
            rtol=rtol,
            atol=atol
        )
        
        # Prepare output
        result = {
            't': sol.t,
            'y': sol.y,
            'message': sol.message,
            'status': sol.status,
            'state_names': self.state_names
        }
        
        return result


def save_simulation_results(result: Dict, 
                           filepath: Path,
                           params: ModelParameters) -> None:
    """
    Save simulation results to file.
    
    Args:
        result: Dictionary from simulate() method
        filepath: Path to save file
        params: ModelParameters object
    """
    # Create output directory if it doesn't exist
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    # Save to numpy file (efficient for large arrays)
    npz_path = filepath.with_suffix('.npz')
    np.savez(
        npz_path,
        t=result['t'],
        y=result['y'],
        state_names=result['state_names']
    )
    print(f"✓ Simulation data saved to: {npz_path}")
    
    # Save summary as JSON
    summary = {
        'integration_status': 'Success' if result['status'] == 0 else 'Failed',
        'message': result['message'],
        'time_span': [float(result['t'][0]), float(result['t'][-1])],
        'num_time_steps': len(result['t']),
        'state_variables': result['state_names'],
        'parameters': {k: getattr(params, k) for k in params.__dataclass_fields__}
    }
    
    json_path = filepath.with_suffix('.json')
    with open(json_path, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"✓ Summary information saved to: {json_path}")


def load_simulation_results(npz_path: Path) -> Dict:
    """
    Load simulation results from npz file.
    
    Args:
        npz_path: Path to the .npz file
    
    Returns:
        Dictionary with 't', 'y', and 'state_names'
    """
    data = np.load(npz_path)
    return {
        't': data['t'],
        'y': data['y'],
        'state_names': data['state_names'].tolist()
    }


def run_simulation(duration: float = 100.0,
                   dt: float = 0.01,
                   x0: Optional[np.ndarray] = None,
                   params: Optional[ModelParameters] = None,
                   output_file: str = 'tumor_immune_simulation.npz',
                   method: str = 'RK45') -> Dict:
    """
    Convenience function to run a simulation with default or custom parameters.
    
    Args:
        duration: Simulation duration in days
        dt: Time step in days
        x0: Initial conditions. If None, uses default initial conditions.
        params: ModelParameters object. If None, uses defaults.
        output_file: Path to save results
        method: Integration method
    
    Returns:
        Simulation results dictionary
    """
    
    # Default initial conditions (small populations at baseline)
    if x0 is None:
        x0 = np.array([
            1e7,    # S: Sensitive tumor cells
            1e6,    # S_R: Resistant tumor cells
            1e5,    # C: Cancer stem cells (cycling)
            1e4,    # C_R: Cancer stem cells (resistant)
            1e3,    # M_1: M1 macrophages
            1e3,    # M_2: M2 macrophages
            1e3,    # T_H1: T helper 1 cells
            1e2,    # T_H2: T helper 2 cells
            1e3,    # T_C: Cytotoxic T lymphocytes
            1e3,    # T_reg: Regulatory T cells
            1e-3,   # IL10: Interleukin-10
            1e-3,   # IFN_gamma: Interferon-gamma
            1e-3    # IL2: Interleukin-2
        ])
    
    # Initialize model
    model = TumorImmuneModel(params)
    
    # Run simulation
    print("=" * 70)
    print("TUMOR-IMMUNE MICROENVIRONMENT DYNAMICS SIMULATION")
    print("=" * 70)
    print(f"Duration: {duration} days")
    print(f"Time step: {dt} days")
    print(f"Integration method: {method}")
    print(f"Initial conditions (default): {x0}")
    print()
    
    t_span = (0, duration)
    num_steps = int(duration / dt) + 1
    t_eval = np.linspace(0, duration, num_steps)
    
    result = model.simulate(
        x0=x0,
        t_span=t_span,
        t_eval=t_eval,
        max_step=dt,
        method=method,
        rtol=1e-6,
        atol=1e-9
    )
    
    # Print integration status
    print(f"Integration Status: {result['message']}")
    print(f"Time steps completed: {len(result['t'])}")
    print()
    
    # Save results
    output_path = Path(output_file)
    save_simulation_results(result, output_path, params or ModelParameters())
    print()
    
    return result


if __name__ == "__main__":
    """
    Example usage: Run simulation with default parameters and initial conditions.
    
    This will:
    1. Simulate the 13-D tumor-immune model for 100 days
    2. Use RK45 (Runge-Kutta 4/5) method with dt=0.01 days
    3. Save results to tumor_immune_simulation.npz
    """
    
    # Run simulation with default parameters
    result = run_simulation(
        duration=100.0,
        dt=0.01,
        output_file='tumor_immune_simulation.npz',
        method='RK45'
    )
    
    # Print final state
    print("Final state values:")
    print("-" * 70)
    state_names = result['state_names']
    y_final = result['y'][:, -1]
    for i, (name, value) in enumerate(zip(state_names, y_final)):
        print(f"  {name:12s}: {value:.6e}")
    print("-" * 70)
