# TUMOR-IMMUNE ODE SIMULATION PROJECT
## Complete Guide to the 13-Dimensional Model Implementation

---

## PROJECT SCOPE

This project reproduces a 13-dimensional deterministic ODE system modeling immunoregulatory mechanisms in the tumor microenvironment, as described in:

**"Exploring immunoregulatory mechanisms in the tumour microenvironment: Model and design of protocols for cancer remission"**

### Current Phase: Simulation Engine ✓ COMPLETE

This phase implements:
- The complete 13-D ODE system with all state variables and equations
- All 72 model parameters with default values
- Flexible ODE solver (scipy.integrate.solve_ivp) with configurable methods and tolerances
- Input parameters for:
  - Initial conditions (x0)
  - Simulation duration
  - Time step / integration method
- Trajectory output saving to .npz files (efficient for large arrays)
- Metadata saving to .json files (for reproducibility)

### Future Phases: Analysis Tools (to be implemented)
1. **Bifurcation Analysis** - Identify parameter regimes and transitions
2. **Sensitivity Analysis** - Determine key parameters affecting outcomes
3. **Visualization Tools** - Phase portraits, time series, parameter sweeps
4. **Parameter Estimation** - Fit to experimental data

---

## FILE GUIDE

### MAIN SIMULATION SCRIPT

**`simulate_tumor_immune_model.py`** (Primary executable)

The core ODE simulation engine containing:

#### Classes
- **`ModelParameters`**: Dataclass holding all 72 parameters with defaults
- **`TumorImmuneModel`**: Main class implementing the 13-D ODE system
  - Method `_rhs()`: Computes time derivatives for all 13 state variables
  - Method `simulate()`: Runs ODE solver with configurable options

#### Functions
- **`run_simulation()`**: Convenience wrapper for typical usage
- **`save_simulation_results()`**: Save trajectory and metadata to disk
- **`load_simulation_results()`**: Load .npz files back into memory

#### Main Block
Example script that runs a 100-day simulation with default parameters.

---

### UTILITIES & EXAMPLES

**`tumor_immune_utils.py`** (Supporting module)

Contains:
- **`print_simulation_summary()`**: Display results from saved simulations
- **`get_state_by_name()`**: Extract specific state variable from results
- **`compute_phase_portrait()`**: Extract two variables for phase plane analysis
- **Six example functions** demonstrating different use cases:
  1. Default simulation
  2. High tumor burden scenario
  3. Immunotherapy boost
  4. High-resolution simulation
  5. Ensemble of simulations
  6. Custom parameter modification

---

## THE 13-STATE ODE SYSTEM

### State Variables (in order x[0] through x[12])

#### Tumor Cell Populations (4)
```
x[0]:  S       - Sensitive (chemotherapy-responsive) tumor cells
x[1]:  S_R     - Resistant tumor cells  
x[2]:  C       - Cancer stem cells (cycling/proliferative)
x[3]:  C_R     - Cancer stem cells (resistant/quiescent)
```

#### Immune Effector Cells (4)
```
x[4]:  M_1     - M1 macrophages (pro-inflammatory, anti-tumor)
x[5]:  M_2     - M2 macrophages (anti-inflammatory, pro-tumor)
x[6]:  T_H1    - T helper 1 cells (Th1 response)
x[7]:  T_H2    - T helper 2 cells (Th2 response)
```

#### Cytotoxic & Regulatory (2)
```
x[8]:  T_C     - Cytotoxic T lymphocytes (CTLs)
x[9]:  T_reg   - Regulatory T cells (immunosuppressive)
```

#### Cytokines (3)
```
x[10]: IL10    - Interleukin-10 (anti-inflammatory)
x[11]: IFN_γ   - Interferon-gamma (pro-inflammatory)
x[12]: IL2     - Interleukin-2 (T cell growth factor)
```

### ODE Structure

Each equation follows the general form:
```
dx[i]/dt = (proliferation terms) - (degradation terms) 
         + (positive interactions) - (negative interactions)
```

**Key Features:**
- Nonlinear Michaelis-Menten terms: `(a*x)/(k+x)`
- Logarithmic growth: `log(C_max/(x+r))`
- Saturation effects through Langmuir kinetics
- Cell-to-cell interactions (competition, cooperation)
- Cytokine-mediated regulation

---

## GETTING STARTED

### Installation

```bash
# Ensure Python 3.8+ is installed
python --version

# Install required packages
pip install numpy scipy

# Verify installation
python -c "import numpy, scipy; print('✓ All packages ready')"
```

### Running Your First Simulation

#### Method 1: Command Line (simplest)
```bash
cd /path/to/project
python simulate_tumor_immune_model.py
```

This runs:
- 100-day simulation
- Default initial conditions (small populations at baseline)
- Default parameters
- RK45 integration with dt=0.01
- Saves to `tumor_immune_simulation.npz`

#### Method 2: Python Script (custom parameters)
```python
from simulate_tumor_immune_model import run_simulation
import numpy as np

# Custom initial conditions (high tumor burden)
x0 = np.array([
    1e9, 1e8, 1e7, 1e6,  # Tumor cells (higher)
    1e3, 1e3, 1e3, 1e2,  # Immune effector cells
    1e2, 1e2,            # CTLs and Tregs (lower)
    1e-3, 1e-3, 1e-3     # Cytokines
])

result = run_simulation(
    duration=200.0,           # 200 days
    dt=0.01,                  # 0.01 day time step
    x0=x0,                    # Use custom initial conditions
    output_file='my_sim.npz'
)
```

#### Method 3: Direct Model Usage (maximum control)
```python
import numpy as np
from simulate_tumor_immune_model import TumorImmuneModel, ModelParameters

# Create model with custom parameters
params = ModelParameters()
params.gamma_Tc *= 1.5  # Boost T cell proliferation
params.tck *= 2.0       # Increase killing rate

model = TumorImmuneModel(params)

# Setup simulation
x0 = np.array([1e7, 1e6, 1e5, 1e4, 1e3, 1e3, 1e3, 1e2, 1e3, 1e3, 1e-3, 1e-3, 1e-3])
t_span = (0, 100)
t_eval = np.linspace(0, 100, 10001)  # 0.01 day resolution

# Run
result = model.simulate(
    x0=x0,
    t_span=t_span,
    t_eval=t_eval,
    method='RK45',
    rtol=1e-6,
    atol=1e-9
)

# Save
from simulate_tumor_immune_model import save_simulation_results
from pathlib import Path
save_simulation_results(result, Path('my_custom_sim.npz'), params)
```

---

## PARAMETER MODIFICATION EXAMPLES

### Example 1: Increase Immune Response (Immunotherapy)

```python
from simulate_tumor_immune_model import ModelParameters, run_simulation

params = ModelParameters()

# Increase T cell proliferation and activation
params.gamma_Th1 *= 1.5      # T_H1 proliferation
params.gamma_Tc *= 1.5       # T_C proliferation
params.lambda_Th1 *= 0.7     # Lower activation threshold
params.lambda_Tc1 *= 0.7     # Lower activation threshold

# Increase cytokine production (stronger signals)
params.beta_Th1CK2 *= 2.0    # IFN-gamma production
params.beta_Tc *= 2.0        # IFN-gamma from CTLs

# Increase T cell killing effectiveness
params.tck *= 2.5            # Triple killing rate

result = run_simulation(
    duration=100,
    params=params,
    output_file='immunotherapy_enhanced.npz'
)
```

### Example 2: Increase Tumor Aggressiveness

```python
from simulate_tumor_immune_model import ModelParameters, run_simulation

params = ModelParameters()

# Increase tumor proliferation
params.gamma_S *= 1.5        # Sensitive cell growth
params.gamma_C *= 1.5        # Stem cell growth

# Decrease tumor cell death
params.delta_S *= 0.5        # Reduce natural death
params.delta_C *= 0.7        # Reduce stem cell death

# Increase immunosuppression
params.mu_TcTreg *= 2.0      # Treg suppression of CTLs
params.gamma_Treg *= 1.2     # Treg proliferation

result = run_simulation(
    duration=100,
    params=params,
    output_file='aggressive_tumor.npz'
)
```

### Example 3: M1 vs M2 Macrophage Switch

```python
from simulate_tumor_immune_model import ModelParameters, run_simulation

# Scenario: Increase anti-tumor M1 macrophages
params_m1 = ModelParameters()
params_m1.gamma_M1 *= 2.0    # Increase M1 proliferation
params_m1.delta_M2 *= 2.0    # Increase M2 death
params_m1.lambda_M1 *= 0.8   # Lower M1 activation threshold

result_m1 = run_simulation(
    duration=100,
    params=params_m1,
    output_file='m1_dominant.npz'
)

# Scenario: Increase pro-tumor M2 macrophages
params_m2 = ModelParameters()
params_m2.gamma_M2 *= 2.0    # Increase M2 proliferation
params_m2.delta_M1 *= 2.0    # Increase M1 death
params_m2.lambda_M2 *= 0.8   # Lower M2 activation threshold

result_m2 = run_simulation(
    duration=100,
    params=params_m2,
    output_file='m2_dominant.npz'
)
```

---

## WORKING WITH RESULTS

### Loading and Inspecting

```python
from pathlib import Path
from simulate_tumor_immune_model import load_simulation_results
from tumor_immune_utils import print_simulation_summary, get_state_by_name

# Load results
result = load_simulation_results(Path('tumor_immune_simulation.npz'))

# Print formatted summary
print_simulation_summary(Path('tumor_immune_simulation.npz'))

# Access raw data
t = result['t']                           # Time array [0, ..., T]
y = result['y']                           # Array of shape (13, len(t))
state_names = result['state_names']       # ['S', 'S_R', 'C', 'C_R', ...]

# Get specific state variable
time, T_C_trajectory = get_state_by_name(result, 'T_C')
```

### Output File Format

Each simulation generates two files:

**filename.npz** (NumPy compressed)
```python
import numpy as np
data = np.load('simulation.npz')
t = data['t']                    # Time: shape (n_steps,)
y = data['y']                    # Trajectories: shape (13, n_steps)
state_names = data['state_names']  # Names of 13 variables
```

**filename.json** (Metadata)
```json
{
  "integration_status": "Success",
  "message": "The solver successfully reached the end of the integration interval.",
  "time_span": [0, 100],
  "num_time_steps": 10001,
  "state_variables": ["S", "S_R", "C", "C_R", ...],
  "parameters": {
    "beta_M2": 1e-15,
    "gamma_S": 0.15,
    ...
  }
}
```

---

## INTEGRATION METHODS & TOLERANCES

### Available Methods

The simulator uses SciPy's `solve_ivp` which supports:

```python
# Fast, adaptive (default - recommended)
result = model.simulate(x0, t_span, method='RK45')

# Higher order, very accurate
result = model.simulate(x0, t_span, method='DOP853')

# For potentially stiff systems
result = model.simulate(x0, t_span, method='Radau')

# For very stiff systems
result = model.simulate(x0, t_span, method='BDF')
```

### Tolerance Settings

```python
# Quick exploration (may sacrifice accuracy)
result = model.simulate(x0, t_span, rtol=1e-5, atol=1e-8)

# Standard (default - good balance)
result = model.simulate(x0, t_span, rtol=1e-6, atol=1e-9)

# High precision (for bifurcation analysis)
result = model.simulate(x0, t_span, rtol=1e-8, atol=1e-11)

# Very high precision (expensive)
result = model.simulate(x0, t_span, rtol=1e-10, atol=1e-12)
```

### Recommended Settings by Task

| Task | Method | rtol | atol | Notes |
|------|--------|------|------|-------|
| Exploration | RK45 | 1e-6 | 1e-9 | Fast, smooth |
| Parameter sweep | RK45 | 1e-5 | 1e-8 | Faster |
| Standard paper | RK45 | 1e-6 | 1e-9 | Default |
| Bifurcation | DOP853 | 1e-8 | 1e-11 | High accuracy |
| Publication | DOP853 | 1e-8 | 1e-12 | Very high accuracy |

---

## INTERPRETING DYNAMICS

### Key Observables

1. **Total Tumor Burden**: S + S_R + C + C_R
2. **T cell/Tumor Ratio**: T_C / (Total Tumor)
3. **M1/M2 Ratio**: M_1 / M_2 (immune polarization)
4. **Th1/Th2 Ratio**: T_H1 / T_H2 (immune response type)
5. **Cytokine Balance**: IFN_γ / IL10 (pro/anti-inflammatory)

### Expected Dynamics

**Scenario 1: Control (Balanced Immune)**
- Tumor held in check or slowly declining
- Sustained moderate immune population
- Fluctuating cytokine levels

**Scenario 2: Tumor Growth**
- Exponential tumor increase
- Immune exhaustion or suppression
- M2 macrophage dominance

**Scenario 3: Tumor Elimination**
- Rapid tumor decline
- M1 macrophage and CTL surge
- IFN-gamma dominance

**Scenario 4: Oscillations**
- Periodic cycles in population levels
- Indicates Hopf bifurcation dynamics
- Common in nonlinear immune models

---

## RUNNING EXAMPLES

The `tumor_immune_utils.py` file contains six complete examples:

```bash
python -c "from tumor_immune_utils import example_default_simulation; example_default_simulation()"
python -c "from tumor_immune_utils import example_custom_initial_conditions; example_custom_initial_conditions()"
python -c "from tumor_immune_utils import example_immunotherapy_boost; example_immunotherapy_boost()"
# etc...
```

Or run all at once:
```bash
python tumor_immune_utils.py
```

---

## TROUBLESHOOTING

### "ModuleNotFoundError: No module named 'scipy'"
```bash
pip install scipy numpy
```

### Simulation runs but produces NaN values
Possible causes:
1. Extreme parameter values
2. Very large dt relative to system dynamics
3. Initial conditions outside biologically reasonable range

Solutions:
```python
# Try finer time stepping
result = model.simulate(x0, t_span, max_step=0.001)

# Try more accurate method
result = model.simulate(x0, t_span, method='DOP853', rtol=1e-8)

# Verify initial conditions are reasonable (should be 0 to 1e10)
print(x0)  # All values should be non-negative and not extreme
```

### Simulation extremely slow
1. You're running very long simulations - that's normal
2. Very tight tolerances can slow down:
   ```python
   result = model.simulate(x0, t_span, rtol=1e-5, atol=1e-8)  # Faster
   ```
3. Try RK45 instead of DOP853

### All populations go to zero or infinity
1. Parameters may be unbalanced - verify defaults
2. Try different initial conditions
3. Check that initial conditions match assumptions

---

## PROJECT ORGANIZATION

```
project_root/
├── simulate_tumor_immune_model.py    ← MAIN: ODE system implementation
├── tumor_immune_utils.py             ← Helper functions and examples
├── README.md                         ← Full documentation
├── IMPLEMENTATION_GUIDE.md           ← This file
└── output/
    ├── tumor_immune_simulation.npz   ← Binary trajectory data
    ├── tumor_immune_simulation.json   ← Metadata
    └── [other saved simulations]
```

---

## KEY PARAMETERS TO MODIFY

For common scenarios, modify these parameters:

**Boost CTL response:**
```python
params.gamma_Tc *= 1.5           # More T_C birth
params.tck *= 2.0                # Better killing
params.beta_Tc *= 1.5            # More IFN-gamma
```

**Increase immunosuppression:**
```python
params.gamma_Treg *= 1.5         # More Treg
params.mu_TcTreg *= 2.0          # Treg suppression of CTL
params.gamma_M2 *= 1.5           # More M2 (pro-tumor)
```

**Make tumor more aggressive:**
```python
params.gamma_S *= 1.5            # Faster growth
params.delta_C *= 0.5            # Less death
params.tck *= 0.2                # Immune resistance
```

---

## NEXT STEPS

After successful trajectory simulation, the next phases will add:

### Phase 2: Bifurcation Analysis
- Identify parameter regimes causing qualitative changes
- Track fixed points and limit cycles
- Generate bifurcation diagrams

### Phase 3: Sensitivity Analysis
- Determine which parameters most strongly affect outcomes
- Use Morris screening or Sobol' indices
- Create tornado plots

### Phase 4: Visualization
- Time series plots with multiple trajectories
- Phase portraits (2D projections)
- Parameter sweep heatmaps

### Phase 5: Parameter Estimation
- Fit model to experimental data
- Bayesian inference with MCMC
- Identifiability testing

---

## PERFORMANCE EXPECTATIONS

| Duration | dt | Steps | Time* |
|----------|----|----|-------|
| 100 days | 0.1 | 1k | 0.5s |
| 100 days | 0.01 | 10k | 2s |
| 100 days | 0.001 | 100k | 20s |
| 500 days | 0.01 | 50k | 10s |

*Approximate on Intel i7, single core, RK45 method

---

## VERIFICATION CHECKLIST

✓ Installation complete: `pip install numpy scipy`
✓ Default run successful: `python simulate_tumor_immune_model.py`
✓ Output files created: `.npz` and `.json` files
✓ Results loadable: `load_simulation_results()` works
✓ Examples run: `python tumor_immune_utils.py` completes
✓ Custom simulation works: Can modify parameters and run

---

**You are now ready to run simulations of the 13-D tumor-immune model!**

Next: Create bifurcation analysis tools or sensitivity analysis scripts as needed.

---

*Last Updated: March 2024*
*Version: 1.0 - Core Simulation Engine*
