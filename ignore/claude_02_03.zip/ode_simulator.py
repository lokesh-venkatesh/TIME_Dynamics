"""
ODE Simulator for 13-Dimensional Tumor-Immune Dynamics Model

This script simulates a deterministic ODE system modeling the interactions
between tumor cells, immune effector cells, and regulatory molecules.

The system consists of 13 state variables:
    1. S - Sensitive tumor cells
    2. S_R - Drug-resistant tumor cells
    3. C - Proliferating cancer cells
    4. C_R - Resistant cancer cells
    5. M_1 - M1 macrophages
    6. M_2 - M2 macrophages
    7. T_H1 - Th1 helper T cells
    8. T_H2 - Th2 helper T cells
    9. T_C - Cytotoxic T cells
    10. T_reg - Regulatory T cells
    11. IL10 - IL-10 cytokine
    12. IFN_gamma - IFN-γ cytokine
    13. IL2 - IL-2 cytokine

Author: Automated Implementation
Reference: Exploring immunoregulatory mechanisms in the tumor microenvironment
"""

import numpy as np
from scipy.integrate import solve_ivp
import os
from datetime import datetime
from dataclasses import dataclass
from typing import Dict, Tuple, Optional
import json


@dataclass
class ModelParameters:
    """Container for all model parameters."""
    
    # Interaction rates (beta parameters)
    beta_M2: float = 1e-15
    beta_Tc: float = 1e-8
    beta_Th1CK2: float = 1e-7
    beta_Th1CK3: float = 1e-8
    beta_Th2: float = 1e-9
    beta_Treg: float = 1e-10
    
    # Decay rates (gamma parameters)
    gamma_C: float = 0.1282
    gamma_CR: float = 0.1282
    gamma_M1: float = 0.7
    gamma_M2: float = 0.01
    gamma_S: float = 0.15
    gamma_Tc: float = 1.0
    gamma_Th1: float = 2.0
    gamma_Th2: float = 2.0
    gamma_Treg: float = 0.3
    
    # Death/Degradation rates (delta parameters)
    delta_C: float = 0.8055
    delta_Ck1: float = 19.757
    delta_Ck2: float = 6.1212
    delta_Ck3: float = 8.664339
    delta_CR: float = 5.37e-5
    delta_M1: float = 1.02
    delta_M2: float = 0.05
    delta_S: float = 2e-7
    delta_Tc: float = 5.2939
    delta_Th1: float = 2.0
    delta_Th2: float = 2.0
    delta_Treg: float = 1.0
    
    # Production/Activation rates (lambda parameters)
    lambda_M1: float = 1e8
    lambda_M2: float = 1e6
    lambda_Tc1: float = 1e5
    lambda_Tc2: float = 5e5
    lambda_Tc3: float = 5e10
    lambda_Tc4: float = 1e5
    lambda_Th1: float = 1e5
    lambda_Th2: float = 1e5
    lambda_Treg2: float = 1e7
    
    # Interaction coefficients (mu parameters)
    mu_C1: float = 0.75
    mu_C2: float = 0.9
    mu_S: float = 0.17
    mu_SR: float = 0.18
    mu_TcS: float = 1e-10
    mu_TcTreg: float = 1.5e-5
    mu_Th1Ck1: float = 1e-9
    mu_Th1Ck3: float = 0.1245
    mu_TregCk1: float = 1e-7
    mu_M1Ck2: float = 0.01
    mu_M2Ck1: float = 0.02
    
    # Capacity and half-saturation constants
    C_max: float = 1e10
    CR_max: float = 1e10
    k1: float = 10.0
    k2: float = 10.0
    k3: float = 2.0531
    k4: float = 3.02
    k5: float = 6.7979
    k6: float = 6.9937
    k7: float = 0.2
    k8: float = 0.01
    k9: float = 0.001
    k10: float = 0.0
    k11: float = 0.001
    
    # Half-saturation constants for T cells
    ktc1: float = 1e9
    ktc2: float = 1e8
    ktc3: float = 1e9
    ktc4: float = 1e9
    
    # Phenotypic switching rates
    m_C: float = 0.01
    m_S: float = 4e-7
    
    # Proliferation fractions
    p_1: float = 0.2
    p_2: float = 0.05
    
    # Tumor cell half-saturation constants
    r_1: float = 0.0001
    r_2: float = 1e-5
    
    # T cell killing rate
    tck: float = 0.1
    
    def to_dict(self) -> Dict:
        """Convert parameters to dictionary."""
        return self.__dict__
    
    @classmethod
    def from_dict(cls, param_dict: Dict) -> 'ModelParameters':
        """Create ModelParameters instance from dictionary."""
        return cls(**param_dict)


class TumorImmuneModel:
    """
    13-dimensional ODE system for tumor-immune dynamics.
    
    State variables (in order):
        x[0]: S - Sensitive tumor cells
        x[1]: S_R - Drug-resistant tumor cells
        x[2]: C - Proliferating cancer cells
        x[3]: C_R - Resistant cancer cells
        x[4]: M_1 - M1 macrophages
        x[5]: M_2 - M2 macrophages
        x[6]: T_H1 - Th1 helper T cells
        x[7]: T_H2 - Th2 helper T cells
        x[8]: T_C - Cytotoxic T cells
        x[9]: T_reg - Regulatory T cells
        x[10]: IL10 - IL-10 cytokine
        x[11]: IFN_gamma - IFN-γ cytokine
        x[12]: IL2 - IL-2 cytokine
    """
    
    # Variable names for reference and output
    variable_names = [
        'S', 'S_R', 'C', 'C_R', 'M_1', 'M_2', 
        'T_H1', 'T_H2', 'T_C', 'T_reg', 
        'IL10', 'IFN_gamma', 'IL2'
    ]
    
    def __init__(self, params: Optional[ModelParameters] = None):
        """
        Initialize the model.
        
        Args:
            params: ModelParameters instance. If None, default parameters are used.
        """
        self.params = params if params is not None else ModelParameters()
    
    def ode_system(self, t: float, x: np.ndarray) -> np.ndarray:
        """
        Compute derivatives for the 13-D ODE system.
        
        Args:
            t: Current time (not used in time-invariant system)
            x: State vector of length 13
            
        Returns:
            Derivative vector dx/dt
        """
        # Unpack state variables
        S, S_R, C, C_R, M_1, M_2, T_H1, T_H2, T_C, T_reg, IL10, IFN_gamma, IL2 = x
        
        # Extract parameters
        p = self.params
        
        # Initialize derivative vector
        dx = np.zeros(13)
        
        # ========== TUMOR CELL DYNAMICS ==========
        
        # dx[0]: dS/dt - Sensitive tumor cells
        dx[0] = (p.gamma_S * (1 - p.m_S) * (1 - p.p_1 - p.p_2) * S 
                 - (p.delta_S + p.p_2 * p.gamma_S + p.gamma_S * p.m_S * p.p_1 / 2) * S
                 - (p.mu_S * S * IFN_gamma) / (p.k1 + IFN_gamma)
                 - (p.tck * S * T_C) / (p.ktc1 + T_C))
        
        # dx[1]: dS_R/dt - Drug-resistant tumor cells
        dx[1] = ((p.gamma_S * (1 - p.p_1 - p.p_2) - (p.delta_S + p.p_2 * p.gamma_S)) * S_R
                 + p.m_S * p.gamma_S * (1 - p.p_1 / 2 - p.p_2) * S
                 - (p.mu_SR * S_R * IFN_gamma) / (p.k2 + IFN_gamma)
                 - (p.tck * S_R * T_C) / (p.ktc2 + T_C))
        
        # dx[2]: dC/dt - Proliferating cancer cells
        dx[2] = (p.gamma_C * (1 - p.m_C) * np.log((p.C_max) / (C + p.r_1)) * C
                 + p.gamma_S * (p.p_1 + p.p_2) * S
                 - p.delta_C * C
                 - p.m_C * p.gamma_C * C
                 + (p.mu_C1 * C * IL10) / (IL10 + p.k3)
                 - (p.mu_C2 * C * IFN_gamma) / (IFN_gamma + p.k4)
                 - (p.tck * C * T_C) / (p.ktc3 + T_C))
        
        # dx[3]: dC_R/dt - Resistant cancer cells
        dx[3] = (p.gamma_C * C_R * np.log((p.CR_max) / (C_R + p.r_2))
                 + p.gamma_S * S_R * (p.p_1 + p.p_2)
                 + p.m_C * p.gamma_C * C
                 - p.delta_CR * C_R
                 + (p.mu_C1 * C_R * IL10) / (IL10 + p.k5)
                 - (p.mu_C2 * C_R * IFN_gamma) / (IFN_gamma + p.k6)
                 - (p.tck * C_R * T_C) / (p.ktc4 + T_C))
        
        # ========== EFFECTOR CELL DYNAMICS ==========
        
        # dx[4]: dM_1/dt - M1 macrophages
        dx[4] = (p.gamma_M1 * M_1 * ((C + C_R) / (M_1 + p.lambda_M1))
                 - p.delta_M1 * M_1
                 + (p.mu_M1Ck2 * M_1 * IFN_gamma) / (IFN_gamma + p.k7))
        
        # dx[5]: dM_2/dt - M2 macrophages
        dx[5] = (p.gamma_M2 * M_2 * ((C + C_R) / (M_2 + p.lambda_M2))
                 - p.delta_M2 * M_2
                 + (p.mu_M2Ck1 * M_2 * IL10) / (IL10 + p.k10))
        
        # dx[6]: dT_H1/dt - Th1 helper T cells
        dx[6] = (p.gamma_Th1 * ((T_H1 * M_1) / (p.lambda_Th1 + T_H1))
                 - p.delta_Th1 * T_H1
                 - (p.mu_Th1Ck1 * IL10 * T_H1) / (IL10 + p.k8)
                 + (p.mu_Th1Ck3 * IL2 * T_H1) / (IL2 + p.k9))
        
        # dx[7]: dT_H2/dt - Th2 helper T cells
        dx[7] = (p.gamma_Th2 * ((T_H2 * M_2) / (p.lambda_Th2 + T_H2))
                 - p.delta_Th2 * T_H2)
        
        # dx[8]: dT_C/dt - Cytotoxic T cells
        dx[8] = (p.gamma_Tc * T_C * ((C + C_R) / (T_C + p.lambda_Tc1))
                 + p.gamma_Tc * ((T_C * T_H1) / (T_C + p.lambda_Tc4))
                 - p.mu_TcS * T_C * ((S + S_R) / (T_C + p.lambda_Tc2))
                 - p.delta_Tc * T_C
                 - p.mu_TcTreg * T_C * ((T_reg) / (p.lambda_Tc3 + T_reg)))
        
        # ========== INHIBITOR CELL DYNAMICS ==========
        
        # dx[9]: dT_reg/dt - Regulatory T cells
        dx[9] = (p.gamma_Treg * ((T_reg * M_2) / (T_reg + p.lambda_Treg2))
                 - p.delta_Treg * T_reg
                 + p.mu_TregCk1 * ((IL10 * T_reg) / (T_reg + p.k11)))
        
        # ========== CYTOKINE DYNAMICS ==========
        
        # dx[10]: dIL10/dt - IL-10 cytokine
        dx[10] = (p.beta_M2 * M_2
                  - p.delta_Ck1 * IL10
                  + p.beta_Treg * T_reg
                  + p.beta_Th2 * T_H2)
        
        # dx[11]: dIFN_gamma/dt - IFN-γ cytokine
        dx[11] = (p.beta_Th1CK2 * T_H1
                  + p.beta_Tc * T_C
                  - p.delta_Ck2 * IFN_gamma)
        
        # dx[12]: dIL2/dt - IL-2 cytokine
        dx[12] = (p.beta_Th1CK3 * T_H1
                  - p.delta_Ck3 * IL2)
        
        return dx
    
    def simulate(self, 
                 t_span: Tuple[float, float],
                 initial_conditions: np.ndarray,
                 max_step: float = 0.1,
                 num_points: Optional[int] = None,
                 method: str = 'RK45',
                 dense_output: bool = True,
                 rtol: float = 1e-6,
                 atol: float = 1e-9) -> Dict:
        """
        Simulate the ODE system.
        
        Args:
            t_span: Tuple of (t_start, t_end) for simulation timespan
            initial_conditions: Initial state vector of length 13
            max_step: Maximum step size for the integrator (default 0.1)
            num_points: If specified, return solution at these number of evenly spaced points.
                       If None, uses solver's internal stepping.
            method: Integration method ('RK45', 'RK23', 'DOP853', 'Radau', 'BDF')
            dense_output: If True, generates dense output for smooth interpolation
            rtol: Relative tolerance for the ODE solver
            atol: Absolute tolerance for the ODE solver
            
        Returns:
            Dictionary containing:
                't': Time points
                'x': Solution array (time points x state variables)
                'sol': Dense solution object (if dense_output=True)
                'success': Boolean indicating successful integration
                'message': Integration message
        """
        
        # Setup evaluation time points
        if num_points is not None:
            t_eval = np.linspace(t_span[0], t_span[1], num_points)
        else:
            t_eval = None
        
        # Solve ODE
        solution = solve_ivp(
            fun=self.ode_system,
            t_span=t_span,
            y0=initial_conditions,
            method=method,
            t_eval=t_eval,
            max_step=max_step,
            dense_output=dense_output,
            rtol=rtol,
            atol=atol
        )
        
        return {
            't': solution.t,
            'x': solution.y.T,  # Transpose to get (n_points, n_variables) shape
            'sol': solution.sol if dense_output else None,
            'success': solution.status == 0,
            'message': solution.message,
            'method': method,
            'nfev': solution.nfev,
            'njev': solution.njev,
            'nlu': solution.nlu
        }


class SimulationRunner:
    """Handle simulation execution and result saving."""
    
    def __init__(self, output_dir: str = './simulation_results'):
        """
        Initialize the runner.
        
        Args:
            output_dir: Directory to save simulation results
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def run_simulation(self,
                      model: TumorImmuneModel,
                      t_span: Tuple[float, float],
                      initial_conditions: np.ndarray,
                      max_step: float = 0.1,
                      num_points: Optional[int] = None,
                      simulation_name: Optional[str] = None,
                      save_results: bool = True,
                      **solver_kwargs) -> Dict:
        """
        Run a simulation and optionally save results.
        
        Args:
            model: TumorImmuneModel instance
            t_span: Tuple of (t_start, t_end)
            initial_conditions: Initial state vector
            max_step: Maximum step size for integrator
            num_points: Number of output points
            simulation_name: Name for this simulation (used in filenames)
            save_results: Whether to save results to file
            **solver_kwargs: Additional arguments for solve_ivp
            
        Returns:
            Dictionary with simulation results and metadata
        """
        
        # Run simulation
        print(f"Starting simulation: {simulation_name if simulation_name else 'unnamed'}")
        print(f"Time span: {t_span[0]:.2f} to {t_span[1]:.2f}")
        print(f"Initial conditions: {initial_conditions}")
        
        results = model.simulate(
            t_span=t_span,
            initial_conditions=initial_conditions,
            max_step=max_step,
            num_points=num_points,
            **solver_kwargs
        )
        
        # Package metadata
        metadata = {
            'simulation_name': simulation_name,
            'timestamp': datetime.now().isoformat(),
            't_span': t_span,
            'initial_conditions': initial_conditions.tolist(),
            'max_step': max_step,
            'num_points': num_points,
            'num_output_points': len(results['t']),
            'integration_method': results['method'],
            'success': results['success'],
            'message': results['message'],
            'nfev': results['nfev'],
            'njev': results['njev'],
            'nlu': results['nlu'],
            'parameters': model.params.to_dict()
        }
        
        # Save if requested
        if save_results:
            self._save_results(results, metadata, simulation_name)
        
        return {
            'results': results,
            'metadata': metadata
        }
    
    def _save_results(self, results: Dict, metadata: Dict, simulation_name: Optional[str]):
        """Save simulation results and metadata to files."""
        
        if simulation_name is None:
            simulation_name = f"simulation_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Create subdirectory for this simulation
        sim_dir = os.path.join(self.output_dir, simulation_name)
        os.makedirs(sim_dir, exist_ok=True)
        
        # Save trajectory data
        trajectory_file = os.path.join(sim_dir, 'trajectory.npy')
        np.save(trajectory_file, results['x'])
        print(f"Saved trajectory to {trajectory_file}")
        
        # Save time points
        time_file = os.path.join(sim_dir, 'time.npy')
        np.save(time_file, results['t'])
        print(f"Saved time points to {time_file}")
        
        # Save as CSV for easy inspection
        csv_file = os.path.join(sim_dir, 'trajectory.csv')
        header = 'time,' + ','.join(TumorImmuneModel.variable_names)
        data = np.column_stack([results['t'], results['x']])
        np.savetxt(csv_file, data, header=header, delimiter=',', comments='')
        print(f"Saved trajectory CSV to {csv_file}")
        
        # Save metadata
        metadata_file = os.path.join(sim_dir, 'metadata.json')
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        print(f"Saved metadata to {metadata_file}")
        
        # Save parameter file
        params_file = os.path.join(sim_dir, 'parameters.json')
        with open(params_file, 'w') as f:
            json.dump(metadata['parameters'], f, indent=2)
        print(f"Saved parameters to {params_file}")
        
        print(f"\nAll results saved to {sim_dir}")
        
        return sim_dir


def main():
    """
    Example usage: Run a sample simulation.
    """
    
    # Create model with default parameters
    params = ModelParameters()
    model = TumorImmuneModel(params=params)
    
    # Define simulation parameters
    t_start = 0.0
    t_end = 365.0  # 1 year in days
    
    # Initial conditions (13 variables)
    # You can modify these as needed
    initial_conditions = np.array([
        1e6,      # S - Sensitive tumor cells
        1e5,      # S_R - Drug-resistant tumor cells
        5e5,      # C - Proliferating cancer cells
        1e4,      # C_R - Resistant cancer cells
        1e3,      # M_1 - M1 macrophages
        1e2,      # M_2 - M2 macrophages
        1e3,      # T_H1 - Th1 helper T cells
        1e2,      # T_H2 - Th2 helper T cells
        1e4,      # T_C - Cytotoxic T cells
        5e2,      # T_reg - Regulatory T cells
        1.0,      # IL10 - IL-10 cytokine
        1.0,      # IFN_gamma - IFN-γ cytokine
        1.0       # IL2 - IL-2 cytokine
    ])
    
    # Create runner and execute simulation
    runner = SimulationRunner(output_dir='./simulation_results')
    
    sim_output = runner.run_simulation(
        model=model,
        t_span=(t_start, t_end),
        initial_conditions=initial_conditions,
        max_step=0.1,
        num_points=3650,  # ~daily output points
        simulation_name='baseline_scenario',
        save_results=True,
        method='RK45',
        dense_output=True,
        rtol=1e-6,
        atol=1e-9
    )
    
    # Print summary
    results = sim_output['results']
    metadata = sim_output['metadata']
    
    print("\n" + "="*60)
    print("SIMULATION SUMMARY")
    print("="*60)
    print(f"Simulation Name: {metadata['simulation_name']}")
    print(f"Integration Method: {metadata['integration_method']}")
    print(f"Success: {metadata['success']}")
    print(f"Total time points: {metadata['num_output_points']}")
    print(f"Function evaluations: {metadata['nfev']}")
    print(f"\nVariable names (in order):")
    for i, name in enumerate(TumorImmuneModel.variable_names):
        print(f"  {i}: {name}")
    print(f"\nFinal state values:")
    final_state = results['x'][-1]
    for i, (name, value) in enumerate(zip(TumorImmuneModel.variable_names, final_state)):
        print(f"  {name:12s}: {value:.6e}")


if __name__ == '__main__':
    main()
