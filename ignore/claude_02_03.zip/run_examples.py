"""
Example script demonstrating various usage patterns for the ODE simulator.

This script shows how to:
1. Run a single baseline simulation
2. Run simulations with different initial conditions
3. Perform parameter sweeps
4. Load and compare results
"""

import numpy as np
from ode_simulator import TumorImmuneModel, ModelParameters, SimulationRunner
from simulation_utils import (
    create_custom_initial_conditions,
    create_immune_boosted_initial_conditions,
    create_immune_suppressed_initial_conditions,
    create_high_tumor_burden_initial_conditions,
    modify_parameter,
    load_trajectory,
    get_final_state
)


def example_1_baseline_simulation():
    """
    Example 1: Run a single baseline simulation with default parameters.
    """
    print("\n" + "="*70)
    print("EXAMPLE 1: Baseline Simulation")
    print("="*70)
    
    # Create model with default parameters
    model = TumorImmuneModel()
    
    # Define time span and initial conditions
    t_start, t_end = 0.0, 365.0
    ic = create_custom_initial_conditions()
    
    # Run simulation
    runner = SimulationRunner(output_dir='./simulation_results')
    sim_output = runner.run_simulation(
        model=model,
        t_span=(t_start, t_end),
        initial_conditions=ic,
        max_step=0.1,
        num_points=3650,
        simulation_name='example1_baseline',
        save_results=True,
        method='RK45'
    )
    
    return sim_output


def example_2_different_initial_conditions():
    """
    Example 2: Run simulations with different immune response scenarios.
    """
    print("\n" + "="*70)
    print("EXAMPLE 2: Different Initial Condition Scenarios")
    print("="*70)
    
    model = TumorImmuneModel()
    runner = SimulationRunner(output_dir='./simulation_results')
    
    scenarios = {
        'baseline': create_custom_initial_conditions(),
        'immune_boosted': create_immune_boosted_initial_conditions(),
        'immune_suppressed': create_immune_suppressed_initial_conditions(),
        'high_tumor_burden': create_high_tumor_burden_initial_conditions()
    }
    
    results = {}
    
    for scenario_name, ic in scenarios.items():
        print(f"\nRunning scenario: {scenario_name}")
        
        sim_output = runner.run_simulation(
            model=model,
            t_span=(0.0, 365.0),
            initial_conditions=ic,
            max_step=0.1,
            num_points=1000,
            simulation_name=f'example2_{scenario_name}',
            save_results=True
        )
        
        results[scenario_name] = sim_output
    
    # Compare final states
    print("\n" + "-"*70)
    print("Comparison of Final States")
    print("-"*70)
    
    from ode_simulator import TumorImmuneModel as TIM
    variable_names = TIM.variable_names
    
    for scenario_name, sim_output in results.items():
        final_state = sim_output['results']['x'][-1]
        print(f"\n{scenario_name}:")
        print(f"  Tumor cells (S+S_R+C+C_R): {final_state[0] + final_state[1] + final_state[2] + final_state[3]:.2e}")
        print(f"  Immune cells (M1+M2+TH1+TH2+TC+Treg): {final_state[4] + final_state[5] + final_state[6] + final_state[7] + final_state[8] + final_state[9]:.2e}")
        print(f"  T_C (Cytotoxic T cells): {final_state[8]:.2e}")
        print(f"  T_reg (Regulatory T cells): {final_state[9]:.2e}")
    
    return results


def example_3_parameter_modification():
    """
    Example 3: Run simulations with modified parameters.
    """
    print("\n" + "="*70)
    print("EXAMPLE 3: Modified Parameters")
    print("="*70)
    
    runner = SimulationRunner(output_dir='./simulation_results')
    ic = create_custom_initial_conditions()
    
    # Test scenarios with different parameters
    scenarios = {
        'default': ModelParameters(),
        'low_delta_C': ModelParameters(delta_C=0.4),  # Lower tumor death rate
        'high_delta_C': ModelParameters(delta_C=1.5),  # Higher tumor death rate
        'low_gamma_S': ModelParameters(gamma_S=0.05),  # Lower tumor growth
        'high_gamma_S': ModelParameters(gamma_S=0.3),  # Higher tumor growth
    }
    
    results = {}
    
    for scenario_name, params in scenarios.items():
        print(f"\nRunning scenario: {scenario_name}")
        
        model = TumorImmuneModel(params=params)
        sim_output = runner.run_simulation(
            model=model,
            t_span=(0.0, 365.0),
            initial_conditions=ic,
            max_step=0.1,
            num_points=1000,
            simulation_name=f'example3_{scenario_name}',
            save_results=True
        )
        
        results[scenario_name] = sim_output
    
    # Compare tumor dynamics
    print("\n" + "-"*70)
    print("Comparison of Tumor Burden at End of Simulation")
    print("-"*70)
    
    for scenario_name, sim_output in results.items():
        final_state = sim_output['results']['x'][-1]
        initial_state = sim_output['metadata']['initial_conditions']
        
        total_tumor_final = final_state[0] + final_state[1] + final_state[2] + final_state[3]
        total_tumor_initial = initial_state[0] + initial_state[1] + initial_state[2] + initial_state[3]
        
        print(f"{scenario_name:20s}: {total_tumor_final:.2e} (initial: {total_tumor_initial:.2e})")
    
    return results


def example_4_custom_simulation():
    """
    Example 4: Custom simulation with specific parameters and initial conditions.
    """
    print("\n" + "="*70)
    print("EXAMPLE 4: Custom Simulation")
    print("="*70)
    
    # Create model with custom parameters
    params = ModelParameters(
        gamma_S=0.1,        # Moderate tumor growth
        delta_C=1.0,        # Moderate tumor death
        gamma_Tc=1.5,       # Enhanced T cell activation
        delta_Tc=3.0,       # Higher T cell death
    )
    
    model = TumorImmuneModel(params=params)
    
    # Custom initial conditions emphasizing immune response
    ic = create_custom_initial_conditions(
        S=5e5,
        S_R=5e4,
        C=2e5,
        C_R=5e3,
        M_1=5e3,
        M_2=1e3,
        T_H1=1e4,
        T_H2=5e3,
        T_C=2e4,
        T_reg=2e3,
        IL10=2.0,
        IFN_gamma=5.0,
        IL2=2.0
    )
    
    # Run for longer period to see long-term dynamics
    runner = SimulationRunner(output_dir='./simulation_results')
    
    sim_output = runner.run_simulation(
        model=model,
        t_span=(0.0, 730.0),  # 2 years
        initial_conditions=ic,
        max_step=0.1,
        num_points=7300,  # ~daily points
        simulation_name='example4_custom',
        save_results=True,
        method='RK45',
        rtol=1e-7,  # Tighter tolerance
        atol=1e-10
    )
    
    # Print dynamics at different timepoints
    print("\nDynamics at different timepoints:")
    results = sim_output['results']
    
    from ode_simulator import TumorImmuneModel as TIM
    
    timepoints = [0, 90, 180, 365, 730]
    for tp in timepoints:
        # Find closest index
        idx = np.argmin(np.abs(results['t'] - tp))
        state = results['x'][idx]
        
        print(f"\nDay {tp}:")
        print(f"  S+S_R: {state[0] + state[1]:.2e}")
        print(f"  C+C_R: {state[2] + state[3]:.2e}")
        print(f"  T_C: {state[8]:.2e}")
        print(f"  T_reg: {state[9]:.2e}")
        print(f"  IL10: {state[10]:.2e}")
        print(f"  IFN_gamma: {state[11]:.2e}")
    
    return sim_output


def example_5_loading_and_analyzing_results():
    """
    Example 5: Load previously saved results and analyze them.
    """
    print("\n" + "="*70)
    print("EXAMPLE 5: Loading and Analyzing Results")
    print("="*70)
    
    # Load a saved simulation
    sim_dir = './simulation_results/example1_baseline'
    
    print(f"\nLoading results from: {sim_dir}")
    
    try:
        trajectory_data = load_trajectory(sim_dir)
        final_state = get_final_state(sim_dir)
        
        print("\nFinal state values:")
        from ode_simulator import TumorImmuneModel as TIM
        for var_name, var_value in final_state.items():
            print(f"  {var_name:12s}: {var_value:.6e}")
        
        # Analyze trajectory
        t = trajectory_data['t']
        x = trajectory_data['x']
        
        print(f"\nTrajectory analysis:")
        print(f"  Time range: {t[0]:.2f} to {t[-1]:.2f}")
        print(f"  Number of points: {len(t)}")
        
        # Calculate growth rates
        print(f"\nTumor burden changes:")
        for i in range(4):  # S, S_R, C, C_R
            var_name = TIM.variable_names[i]
            initial = x[0, i]
            final = x[-1, i]
            ratio = final / initial if initial > 0 else 0
            print(f"  {var_name}: {initial:.2e} → {final:.2e} (ratio: {ratio:.2e})")
        
    except FileNotFoundError:
        print(f"Note: Could not find {sim_dir}. Please run example 1 first.")


def main():
    """Run all examples."""
    
    print("\n" + "="*70)
    print("TUMOR-IMMUNE DYNAMICS ODE SIMULATOR - EXAMPLES")
    print("="*70)
    
    # Run examples
    ex1 = example_1_baseline_simulation()
    ex2 = example_2_different_initial_conditions()
    ex3 = example_3_parameter_modification()
    ex4 = example_4_custom_simulation()
    example_5_loading_and_analyzing_results()
    
    print("\n" + "="*70)
    print("ALL EXAMPLES COMPLETED")
    print("="*70)
    print("\nResults are saved in ./simulation_results/")
    print("\nNext steps:")
    print("  1. Modify initial conditions and parameters in examples above")
    print("  2. Implement bifurcation analysis using saved results")
    print("  3. Implement sensitivity analysis across parameters")
    print("  4. Create visualization scripts to plot trajectories")


if __name__ == '__main__':
    main()
